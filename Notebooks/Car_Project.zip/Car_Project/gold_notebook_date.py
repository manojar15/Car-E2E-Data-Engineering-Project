# Databricks notebook source
init_load = int(dbutils.widgets.get("init_load"))

# COMMAND ----------

init_load

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from parquet.`abfss://silver@carprojectmanoj.dfs.core.windows.net/carsales`;

# COMMAND ----------

df_src = spark.sql(
    """
    SELECT
        DISTINCT(Date_ID) as Date_ID
        FROM parquet.`abfss://silver@carprojectmanoj.dfs.core.windows.net/carsales`
    """
)
df_src.display()

# COMMAND ----------

from pyspark.sql.functions import *

# COMMAND ----------

if init_load == 1:
    df_sink = spark.sql("""
    SELECT
        1 AS dim_date_key,
        Date_ID
        FROM parquet.`abfss://silver@carprojectmanoj.dfs.core.windows.net/carsales`
        where 1=0
    """)
    df_sink.display()
else:
    df_sink = spark.sql("""
    SELECT
        dim_date_key,
        Date_ID
        FROM car_cata.gold.dim_date
    """)
    df_sink.display()

# COMMAND ----------

df_filter = df_src.join(df_sink, ((df_src["Date_ID"] == df_sink["Date_ID"])),"left").select(df_src["Date_ID"],df_sink["dim_date_key"])
df_filter.display()

# COMMAND ----------

df_filter_old = df_filter.filter(df_filter["dim_date_key"].isNotNull())
df_filter_old.display()
df_filter_new = df_filter.filter(df_filter["dim_date_key"].isNull()).select(df_src["Date_ID"])
df_filter_new.display()

# COMMAND ----------

if init_load == 1:
    max_value = 1
else:
    max_value_df = spark.sql("select max(dim_date_key) from car_cata.gold.dim_date")
    max_value = max_value_df.collect()[0][0]+1
print(max_value)

# COMMAND ----------

df_filter_new = df_filter_new.withColumn("dim_date_key",max_value+monotonically_increasing_id())
df_filter_new.display()

# COMMAND ----------

df_filter_final = df_filter_old.union(df_filter_new)
df_filter_final.display()

# COMMAND ----------

from delta.tables import DeltaTable

# COMMAND ----------

if spark.catalog.tableExists("car_cata.gold.dim_date"):
    sparkObj =DeltaTable.forPath(spark,"abfss://gold@carprojectmanoj.dfs.core.windows.net/dim_date")
    sparkObj.alias("trg").merge(df_filter_final.alias("src"),"trg.dim_date_key = src.dim_date_key")\
        .whenMatchedUpdateAll()\
        .whenNotMatchedInsertAll()\
        .execute()
else:
    df_filter_final.write.format("delta")\
        .mode("overwrite")\
        .option("path","abfss://gold@carprojectmanoj.dfs.core.windows.net/dim_date")\
        .saveAsTable("car_cata.gold.dim_date")

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from car_cata.gold.dim_date;