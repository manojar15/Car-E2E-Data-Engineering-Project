# Databricks notebook source
# MAGIC %sql
# MAGIC --create catalog car_cata;

# COMMAND ----------

# MAGIC %sql
# MAGIC --create schema car_cata.bronze;
# MAGIC --create schema car_cata.silver;
# MAGIC --create schema car_cata.gold;

# COMMAND ----------

df = spark.read.format("parquet")\
    .option("inferSChema",True)\
    .load("abfss://bronze@carprojectmanoj.dfs.core.windows.net/rawdata")
df.display()

# COMMAND ----------

from pyspark.sql.functions import *
from pyspark.sql.types import *

# COMMAND ----------

df = df.withColumn("model_category",split(col("Model_ID"),"-")[0])
df.display()

# COMMAND ----------

df.withColumn("Units_Sold",col("Units_Sold").cast("String")).printSchema()

# COMMAND ----------

df = df.withColumn("RevPerUnit",col("Revenue")/col("Units_Sold"))
df.display()

# COMMAND ----------

df.groupBy("Year","BranchName").agg(sum("Units_Sold").alias("Total_units")).sort("Year","Total_units",ascending=[1,0]).display()

# COMMAND ----------

df.write.format("parquet")\
    .mode("overwrite")\
    .save("abfss://silver@carprojectmanoj.dfs.core.windows.net/carsales")

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from parquet.`abfss://silver@carprojectmanoj.dfs.core.windows.net/carsales`;