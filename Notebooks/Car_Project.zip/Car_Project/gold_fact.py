# Databricks notebook source
df =spark.sql("select * from parquet.`abfss://silver@carprojectmanoj.dfs.core.windows.net/carsales`")
df.display()

# COMMAND ----------

df_dim_branch = spark.read.table("car_cata.gold.dim_branch")
df_dim_branch.display()
df_dim_dealer = spark.read.table("car_cata.gold.dim_dealer")
df_dim_dealer.display()
df_dim_model = spark.read.table("car_cata.gold.dim_model")
df_dim_model.display()
df_dim_date = spark.read.table("car_cata.gold.dim_date")
df_dim_date.display()

# COMMAND ----------

df_gold_fact = df.join(df_dim_branch, df.Branch_ID == df_dim_branch.Branch_ID, "left")\
    .join(df_dim_dealer, df.Dealer_ID == df_dim_dealer.Dealer_ID, "left")\
    .join(df_dim_model, df.Model_ID == df_dim_model.Model_ID, "left")\
    .join(df_dim_date, df.Date_ID == df_dim_date.Date_ID, "left")\
    .select(df["Revenue"], df["Units_Sold"],  df["RevPerUnit"], df_dim_branch["dim_branch_key"], df_dim_dealer["dim_dealer_key"], df_dim_model["dim_model_key"], df_dim_date["dim_date_key"])
df_gold_fact.display()


# COMMAND ----------

from delta.tables import DeltaTable

# COMMAND ----------

if spark.catalog.tableExists("car_cata.gold.factsales"):
    deltaObj = DeltaTable.forName(spark, "car_cata.gold.factsales")
    deltaObj.alias("t")\
        .merge(df_gold_fact.alias("s"), "t.dim_branch_key = s.dim_branch_key and t.dim_dealer_key = s.dim_dealer_key and t.dim_model_key = s.dim_model_key and t.dim_date_key = s.dim_date_key")\
        .whenMatchedUpdateAll()\
        .whenNotMatchedInsertAll()\
        .execute()
else:
    df_gold_fact.write.format("delta")\
        .mode("overwrite")\
        .option("path","abfss://gold@carprojectmanoj.dfs.core.windows.net/factsales")\
        .saveAsTable("car_cata.gold.factsales")

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from car_cata.gold.factsales;