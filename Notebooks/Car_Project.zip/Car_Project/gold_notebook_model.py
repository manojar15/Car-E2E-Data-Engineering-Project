# Databricks notebook source
init_load = int(dbutils.widgets.get("init_load"))

# COMMAND ----------

init_load

# COMMAND ----------

df_src = spark.sql(
    """
    SELECT
        DISTINCT(Model_ID) as Model_ID,
        model_category
        FROM parquet.`abfss://silver@carprojectmanoj.dfs.core.windows.net/carsales`
    """
)
df_src.display()

# COMMAND ----------

from pyspark.sql.functions import *

# COMMAND ----------

# MAGIC %sql
# MAGIC --drop table car_cata.gold.dim_model;

# COMMAND ----------

if init_load == 1:
    df_sink = spark.sql("""
    SELECT
        1 AS dim_model_key,
        Model_ID,
        model_category
        FROM parquet.`abfss://silver@carprojectmanoj.dfs.core.windows.net/carsales`
        where 1=0
    """)
    df_sink.display()
else:
    df_sink = spark.sql("""
    SELECT
        dim_model_key,
        Model_ID,
        model_category
        FROM car_cata.gold.dim_model
    """)
    df_sink.display()

# COMMAND ----------

df_filter = df_src.join(df_sink, ((df_src["Model_ID"] == df_sink["Model_ID"])),"left").select(df_src["Model_ID"],df_src["model_category"],df_sink["dim_model_key"])
df_filter.display()

# COMMAND ----------

df_filter_old = df_filter.filter(df_filter["dim_model_key"].isNotNull())
df_filter_old.display()
df_filter_new = df_filter.filter(df_filter["dim_model_key"].isNull()).select(df_src["Model_ID"],df_src["model_category"])
df_filter_new.display()

# COMMAND ----------

if init_load == 1:
    max_value = 1
else:
    max_value_df = spark.sql("select max(dim_model_key) from car_cata.gold.dim_model")
    max_value = max_value_df.collect()[0][0]+1
print(max_value)

# COMMAND ----------

df_filter_new = df_filter_new.withColumn("dim_model_key",max_value+monotonically_increasing_id())
df_filter_new.display()

# COMMAND ----------

df_filter_final = df_filter_old.union(df_filter_new)
df_filter_final.display()

# COMMAND ----------

from delta.tables import DeltaTable

# COMMAND ----------

if spark.catalog.tableExists("car_cata.gold.dim_model"):
    sparkObj =DeltaTable.forPath(spark,"abfss://gold@carprojectmanoj.dfs.core.windows.net/dim_model")
    sparkObj.alias("trg").merge(df_filter_final.alias("src"),"trg.dim_model_key = src.dim_model_key")\
        .whenMatchedUpdateAll()\
        .whenNotMatchedInsertAll()\
        .execute()
else:
    df_filter_final.write.format("delta")\
        .mode("overwrite")\
        .option("path","abfss://gold@carprojectmanoj.dfs.core.windows.net/dim_model")\
        .saveAsTable("car_cata.gold.dim_model")

# COMMAND ----------

# MAGIC %sql
# MAGIC --DROP TABLE car_cata.gold.dim_model

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from car_cata.gold.dim_model;