# Databricks notebook source
init_load = int(dbutils.widgets.get("init_load"))

# COMMAND ----------

init_load

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from parquet.`abfss://silver@carprojectmanoj.dfs.core.windows.net/carsales`;

# COMMAND ----------

df_src = spark.sql(
    """
    SELECT
        DISTINCT(Dealer_ID) as Dealer_ID,
        DealerName
        FROM parquet.`abfss://silver@carprojectmanoj.dfs.core.windows.net/carsales`
    """
)
df_src.display()

# COMMAND ----------

from pyspark.sql.functions import *

# COMMAND ----------

if init_load == 1:
    df_sink = spark.sql("""
    SELECT
        1 AS dim_dealer_key,
        Dealer_ID,
        DealerName
        FROM parquet.`abfss://silver@carprojectmanoj.dfs.core.windows.net/carsales`
        where 1=0
    """)
    df_sink.display()
else:
    df_sink = spark.sql("""
    SELECT
        dim_dealer_key,
        Dealer_ID,
        DealerName
        FROM car_cata.gold.dim_dealer
    """)
    df_sink.display()

# COMMAND ----------

df_filter = df_src.join(df_sink, ((df_src["Dealer_ID"] == df_sink["Dealer_ID"])),"left").select(df_src["Dealer_ID"],df_src["DealerName"],df_sink["dim_dealer_key"])
df_filter.display()

# COMMAND ----------

df_filter_old = df_filter.filter(df_filter["dim_dealer_key"].isNotNull())
df_filter_old.display()
df_filter_new = df_filter.filter(df_filter["dim_dealer_key"].isNull()).select(df_src["Dealer_ID"],df_src["DealerName"])
df_filter_new.display()

# COMMAND ----------

if init_load == 1:
    max_value = 1
else:
    max_value_df = spark.sql("select max(dim_dealer_key) from car_cata.gold.dim_dealer")
    max_value = max_value_df.collect()[0][0]+1
print(max_value)

# COMMAND ----------

df_filter_new = df_filter_new.withColumn("dim_dealer_key",max_value+monotonically_increasing_id())
df_filter_new.display()

# COMMAND ----------

df_filter_final = df_filter_old.union(df_filter_new)
df_filter_final.display()

# COMMAND ----------

from delta.tables import DeltaTable

# COMMAND ----------

if spark.catalog.tableExists("car_cata.gold.dim_dealer"):
    sparkObj =DeltaTable.forPath(spark,"abfss://gold@carprojectmanoj.dfs.core.windows.net/dim_dealer")
    sparkObj.alias("trg").merge(df_filter_final.alias("src"),"trg.dim_dealer_key = src.dim_dealer_key")\
        .whenMatchedUpdateAll()\
        .whenNotMatchedInsertAll()\
        .execute()
else:
    df_filter_final.write.format("delta")\
        .mode("overwrite")\
        .option("path","abfss://gold@carprojectmanoj.dfs.core.windows.net/dim_dealer")\
        .saveAsTable("car_cata.gold.dim_dealer")

# COMMAND ----------

# MAGIC %sql
# MAGIC --DROP TABLE car_cata.gold.dim_dealer

# COMMAND ----------

# MAGIC %sql
# MAGIC select * from car_cata.gold.dim_dealer;